package servlet;

import com.mysql.fabric.xmlrpc.Client;
import dao.ClientDao;
import dao.LocationDao;
import dao.RegisterDao;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Clients;
import model.Location;
import model.User;
import services.ClientService;
import services.LocationService;
import services.RegisterService;

public class RegisterServlet extends HttpServlet {

    RegisterService registerService;
    RegisterDao registerDao;

    String jdbcUserName;
    String jdbcPassword;
    String jdbcURL;

    ///Location
    LocationService locationService;
    LocationDao locationDao;

    ///clients
    ClientService clientService;
    ClientDao clientDao;

    @Override
    public void init() throws ServletException {
        jdbcURL = getServletContext().getInitParameter("jdbcURL");
        jdbcUserName = getServletContext().getInitParameter("jdbcUserName");
        jdbcPassword = getServletContext().getInitParameter("jdbcPassword");

        registerDao = new RegisterDao(jdbcURL, jdbcUserName, jdbcPassword);
        registerService = new RegisterService();

        locationDao = new LocationDao(jdbcURL, jdbcUserName, jdbcPassword);
        locationService = new LocationService();
        clientDao = new ClientDao(jdbcURL, jdbcUserName, jdbcPassword);
        clientService = new ClientService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();

        //String action = request.getParameter("submit");
        switch (action) {
            // Markting AGENT
            case "/new":
                showNewUserForm(request, response);
                break;

            case "/insert":
                addUser(request, response);
                break;

            case "/edit":
                showEditForm(request, response);
                break;

            case "/update":
                updateUser(request, response);
                break;

            case "/delete":
                deleteUser(request, response);
                break;
            case "/list":
                viewUsers(request, response);
                break;

            //location
            case "/newLocation":
                showNewLocationForm(request, response);
                break;

            case "/insertLocation":
                addLocation(request, response);
                break;

            case "/editLocation":
                showEditFormLocation(request, response);
                break;

            case "/updateLocation":
                updateLocation(request, response);
                break;

            case "/deleteLocation":
                deleteLocation(request, response);
                break;
            case "/listLocation":
                viewLocation(request, response);
                break;
            //Client
            case "/newClient":
                showNewClientForm(request, response);
                break;

            case "/insertClient":
                addClient(request, response);
                break;

            case "/editClient":
                showEditFormClient(request, response);
                break;

            case "/updateClient":
                updateClient(request, response);
                break;

            case "/deleteClient":
                deleteClient(request, response);
                break;
            case "/listClient":
                viewClient(request, response);
                break;

            case "/login": {
                try {
                    login(request, response);
                } catch (SQLException ex) {
                    Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            break;
            case "/logout": {
                try {
                    login(request, response);
                } catch (SQLException ex) {
                    Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            break;
            default: {
                try {
                    login(request, response);
                } catch (SQLException ex) {
                    Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            break;

        }
    }

    private void login(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException, SQLException {
        String username, password;
        username = request.getParameter("username");
        password = request.getParameter("password");
        int log = registerDao.login(username, password);
        RequestDispatcher dispatcher;
        if (log == 1) {
            dispatcher = request.getRequestDispatcher("/list");
        } else if (log == 2) {
            dispatcher = request.getRequestDispatcher("/listLocation");
        } else {
            dispatcher = request.getRequestDispatcher("login.jsp");
        }
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void addUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String phoneNo = request.getParameter("phoneNo");
        String email = request.getParameter("email");

        int res = registerService.addUser(firstName, lastName, phoneNo, email, registerDao);

        if (res > 0) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("list");
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    protected void viewUsers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ArrayList<User> userList = new ArrayList();
        userList = registerService.viewUsers(registerDao);

        request.setAttribute("userList", userList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewUserList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewUserForm(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("registerUser.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            User user = registerService.showUser(id, registerDao);
            request.setAttribute("user", user);

            RequestDispatcher dispatcher = request.getRequestDispatcher("editUserForm.jsp");
            dispatcher.forward(request, response);

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String phoneNo = request.getParameter("phoneNo");
        String email = request.getParameter("email");

        int id = Integer.parseInt(request.getParameter("id"));

        User userObj = new User(id, firstName, lastName, phoneNo, email);
        try {
            registerService.updateUser(userObj, registerDao);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        response.sendRedirect("list");
    }

    private void deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        int id = Integer.parseInt(request.getParameter("id"));

        User userObj = new User(id);
        try {
            registerService.deleteUser(userObj, registerDao);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        response.sendRedirect("list?id=" + id);
    }

    // Location
    protected void addLocation(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String locationName = request.getParameter("locationName");
        int distributionCapacity = Integer.parseInt(request.getParameter("distributionCapacity"));
        int res = locationService.addLocation(locationName, distributionCapacity, locationDao);

        if (res > 0) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("listLocation");
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    protected void viewLocation(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ArrayList<Location> locationList = new ArrayList();
        locationList = locationService.viewLocation(locationDao);

        request.setAttribute("locationList", locationList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewLocationList.jsp");
        dispatcher.forward(request, response);

    }

    private void showNewLocationForm(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("registerLocation.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditFormLocation(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            Location location = locationService.showLocation(id, locationDao);
            request.setAttribute("location", location);

            RequestDispatcher dispatcher = request.getRequestDispatcher("editLocationForm.jsp");
            dispatcher.forward(request, response);

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
    }

    private void updateLocation(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String locationName = request.getParameter("locationName");
        int distributionCapacity = Integer.parseInt(request.getParameter("distributionCapacity"));
        int id = Integer.parseInt(request.getParameter("id"));

        Location locObj = new Location(id, locationName, distributionCapacity);
        try {
            locationService.updateLocation(locObj, locationDao);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        response.sendRedirect("listLocation");
    }

    private void deleteLocation(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        int id = Integer.parseInt(request.getParameter("id"));

        Location locObj = new Location(id);
        try {
            locationService.deleteLocation(locObj, locationDao);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        response.sendRedirect("listLocation?id=" + id);
    }

    // Client
    protected void addClient(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int res = clientService.addClient(Integer.parseInt(request.getParameter("agentId")),
                request.getParameter("firstName"),
                request.getParameter("lastName"),
                Integer.parseInt(request.getParameter("streetNumber")),
                request.getParameter("streetName"),
                request.getParameter("city"),
                request.getParameter("province"),
                request.getParameter("postalCode"),
                request.getParameter("telOffice"),
                request.getParameter("telCell"),
                request.getParameter("email"),
                request.getParameter("company"),
                request.getParameter("companyType"),
                clientDao);

        if (res > 0) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/listClient");
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    protected void viewClient(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ArrayList<Clients> clientList = new ArrayList();
        clientList = clientService.viewClients(clientDao);

        request.setAttribute("clientList", clientList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewClientsList.jsp");
        dispatcher.forward(request, response);

    }

    private void showNewClientForm(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("registerClients.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditFormClient(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            Clients client = clientService.showClient(id, clientDao);
            request.setAttribute("client", client);

            RequestDispatcher dispatcher = request.getRequestDispatcher("editClientsForm.jsp");
            dispatcher.forward(request, response);

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
    }

    private void updateClient(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        //  String locationName = request.getParameter("locationName");
        // int distributionCapacity = Integer.parseInt(request.getParameter("distributionCapacity"));
        int id = Integer.parseInt(request.getParameter("id"));

        Clients cliObj = new Clients(Integer.parseInt(request.getParameter("agentId")),
                request.getParameter("firstName"),
                request.getParameter("lastName"),
                Integer.parseInt(request.getParameter("streetNumber")),
                request.getParameter("streetName"),
                request.getParameter("city"),
                request.getParameter("province"),
                request.getParameter("postalCode"),
                request.getParameter("telOffice"),
                request.getParameter("telCell"),
                request.getParameter("email"),
                request.getParameter("company"),
                request.getParameter("companyType"));
        cliObj.setId(id);
        try {
            clientService.updateClient(cliObj, clientDao);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        response.sendRedirect("listClient");
    }

    private void deleteClient(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        int id = Integer.parseInt(request.getParameter("id"));

        Clients cliObj = new Clients(id);
        try {
            clientService.deleteClient(cliObj, clientDao);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        response.sendRedirect("listClient?id=" + id);
    }
}
