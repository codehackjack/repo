package services;
import dao.LocationDao;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Location;

public class LocationService {
    public int addLocation(String locationName, int distributionCapacity,  LocationDao dao){
        int res = 0;
        Location locObj = new Location();
        if(locationName!=null){
            locObj.setLocationName(locationName);
            locObj.setDistributionCapacity(distributionCapacity);
            res = dao.addLocation(locObj);
        }
        return res;
    }
    
    public ArrayList<Location> viewLocation(LocationDao dao){
        ArrayList<Location> locList = new ArrayList();
        locList = dao.viewLocations();
        return locList;
    }
    
    public Location showLocation(int id, LocationDao dao) throws SQLException{
        Location locObj = dao.showLoc(id);
        return locObj;
    }
    
    public boolean updateLocation(Location locObj, LocationDao dao) throws SQLException{
        boolean res = dao.updateLocation(locObj);
        return res;
    }
     public boolean deleteLocation(Location locObj, LocationDao dao) throws SQLException{
        boolean res = dao.deleteLocation(locObj);
        return res;
    }
}