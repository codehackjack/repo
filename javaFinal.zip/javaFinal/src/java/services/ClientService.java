package services;

import dao.ClientDao;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Clients;

public class ClientService {

    public int addClient(int agentId, String firstName, String lastName, int streetNumber, String streetName, String city, String province, String postalCode, String telOffice, String telCell, String email, String company, String companyType, ClientDao dao) {
        int res = 0;

        if (firstName != null) {
            Clients cliObj = new Clients(agentId, firstName, lastName, streetNumber, streetName, city, province, postalCode, telOffice, telCell, email, company, companyType);
            res = dao.addClient(cliObj);
        }
        return res;
    }

    public ArrayList<Clients> viewClients(ClientDao dao) {
        ArrayList<Clients> cliList = new ArrayList();
        cliList = dao.viewClients();
        return cliList;
    }

    public Clients showClient(int id, ClientDao dao) throws SQLException {
        Clients cliObj = dao.showCli(id);
        return cliObj;
    }

    public boolean updateClient(Clients cliObj, ClientDao dao) throws SQLException {
        boolean res = dao.updateClient(cliObj);
        return res;
    }

    public boolean deleteClient(Clients cliObj, ClientDao dao) throws SQLException {
        boolean res = dao.deleteClient(cliObj);
        return res;
    }
}
