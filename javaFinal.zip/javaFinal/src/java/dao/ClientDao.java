package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Clients;
import model.Location;

public class ClientDao {

    private String url;
    private String userDB;
    private String passDB;

    public ClientDao() {
    }

    public ClientDao(String url, String userDB, String passDB) {
        this.url = url;
        this.userDB = userDB;
        this.passDB = passDB;
    }

    protected Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(url, userDB, passDB);
            }
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    public int addClient(Clients cliObj) {
        int res = 0;
        String sql = "INSERT INTO clients (agentId, firstName, lastName, streetNumber, streetName,"
                + " city, province, postalCode, telOffice, telCell, email, company, companyType)"
                + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            Connection conn = getConnection();
            if (conn != null) {
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, cliObj.getAgentId());
                stmt.setString(2, cliObj.getFirstName());
                stmt.setString(3, cliObj.getLastName());
                stmt.setInt(4, cliObj.getStreetNumber());
                stmt.setString(5, cliObj.getStreetName());
                stmt.setString(6, cliObj.getCity());
                stmt.setString(7, cliObj.getProvince());
                stmt.setString(8, cliObj.getPostalCode());
                stmt.setString(9, cliObj.getTelOffice());
                stmt.setString(10, cliObj.getTelCell());
                stmt.setString(11, cliObj.getEmail());
                stmt.setString(12, cliObj.getCompany());
                stmt.setString(13, cliObj.getCompanyType());
                System.out.println(stmt);
                res = stmt.executeUpdate();
                conn.close();
            }

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
        return res;
    }

    public ArrayList<Clients> viewClients() {
        ArrayList<Clients> cliList = new ArrayList();
        String sql = "SELECT * FROM Clients ";
        try {
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery(sql);
            while (resultSet.next()) {

                Clients cliObj = new Clients();
                cliObj.setId(resultSet.getInt("id"));
                cliObj.setAgentId(resultSet.getInt("agentid"));
                cliObj.setFirstName(resultSet.getString("firstname"));
                cliObj.setLastName(resultSet.getString("lastName"));
                cliObj.setStreetNumber(resultSet.getInt("streetNumber"));
                cliObj.setStreetName(resultSet.getString("streetName"));
                cliObj.setCity(resultSet.getString("city"));
                cliObj.setProvince(resultSet.getString("province"));
                cliObj.setPostalCode(resultSet.getString("postalCode"));
                cliObj.setTelOffice(resultSet.getString("telCell"));
                cliObj.setEmail(resultSet.getString("email"));
                cliObj.setCompany(resultSet.getString("company"));
                cliObj.setCompanyType(resultSet.getString("companyType"));

                cliList.add(cliObj);
            }
            resultSet.close();
            stmt.close();
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
        return cliList;
    }

    public Clients showCli(int id) throws SQLException {
        Clients cliObj = null;
        String sql = "SELECT * FROM Clients ";
        sql += "WHERE id = ?";

        Connection con = getConnection();
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {

            cliObj = new Clients();
            cliObj.setId(resultSet.getInt("id"));
            cliObj.setAgentId(resultSet.getInt("agentid"));
            cliObj.setFirstName(resultSet.getString("firstname"));
            cliObj.setLastName(resultSet.getString("lastName"));
            cliObj.setStreetNumber(resultSet.getInt("streetNumber"));
            cliObj.setStreetName(resultSet.getString("streetName"));
            cliObj.setCity(resultSet.getString("city"));
            cliObj.setProvince(resultSet.getString("province"));
            cliObj.setPostalCode(resultSet.getString("postalCode"));
            cliObj.setTelOffice(resultSet.getString("telCell"));
            cliObj.setEmail(resultSet.getString("email"));
            cliObj.setCompany(resultSet.getString("company"));
            cliObj.setCompanyType(resultSet.getString("companyType"));

        }
        return cliObj;
    }

    public boolean updateClient(Clients cliObj) throws SQLException {
        boolean res;
        String sql = "UPDATE location SET agentId = ?, firstName = ?, lastName = ?, "
                + "streetNumber = ?, streetName = ?, city = ?, province = ?, "
                + "postalCode = ?, telOffice = ?, telCell = ?, "
                + "email = ?, company = ?, companyType = ?";
        sql += "WHERE id = ?";
        Connection con = getConnection();
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1, cliObj.getAgentId());
        stmt.setString(2, cliObj.getFirstName());
        stmt.setString(3, cliObj.getLastName());
        stmt.setString(4, cliObj.getStreetName());
        stmt.setInt(5, cliObj.getStreetNumber());
        stmt.setString(6, cliObj.getCity());
        stmt.setString(7, cliObj.getProvince());
        stmt.setString(8, cliObj.getPostalCode());
        stmt.setString(9, cliObj.getTelOffice());
        stmt.setString(10, cliObj.getTelCell());
        stmt.setString(11, cliObj.getEmail());
        stmt.setString(12, cliObj.getCompany());
        stmt.setString(13, cliObj.getCompanyType());
        stmt.setInt(14, cliObj.getId());
        res = stmt.executeUpdate() > 0;

        return res;

    }

    public boolean deleteClient(Clients cliObj) throws SQLException {
        boolean res;
        String sql = "delete from clients ";
        sql += "WHERE id = ?";

        Connection con = getConnection();
        PreparedStatement statement = con.prepareStatement(sql);

        statement.setInt(1, cliObj.getId());

        res = statement.executeUpdate() > 0;

        return res;
    }
}
