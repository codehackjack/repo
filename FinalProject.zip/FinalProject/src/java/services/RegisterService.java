package services;
import dao.RegisterDao;
import java.sql.SQLException;
import java.util.ArrayList;
import model.User;

public class RegisterService {
    public int addUser(String email, String firstName, String lastName, String userName, String password, int typeId, String type,String phoneNO, RegisterDao dao){
        int res = 0;
        User userObj;
        if(userName!=null && email!=null){
            userObj = new User(email, firstName, lastName, userName, password, typeId, type, phoneNO);
            //userObj.setEmail(email);
          
            res = dao.addUser(userObj);
        }
        return res;
    }
    
    public ArrayList<User> viewUsers(RegisterDao dao){
        ArrayList<User> userList = new ArrayList();
        userList = dao.viewUsers();
        return userList;
    }
    
    public User showUser(int id, RegisterDao dao) throws SQLException{
        User userObj = dao.showUser(id);
        return userObj;
    }
    
    public boolean updateUser(User userObj, RegisterDao dao) throws SQLException{
        boolean res = dao.updateUser(userObj);
        return res;
    }
     public boolean deleteUser(User userObj, RegisterDao dao) throws SQLException{
        boolean res = dao.deleteUser(userObj);
        return res;
    }
}