package model;

public class User {
    int userId;
    String email;
    String firstName;
    String lastName;
    String phoneNO;
    String userName;
    String password;
    int typeId;
    String type;
    public User(int userId, String email, String firstName, String lastName, String userName, int typeId, String type,String phoneNO) {
        this.userId = userId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.typeId = typeId;
        this.type = type;
        this.phoneNO = phoneNO;
    }
    public  User(){
    }
    public User(int userId, String userName, String password) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
    }

    public User(int userId, String email, String firstName, String lastName, String phoneNO, String password) {
        this.userId = userId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNO = phoneNO;
        this.password = password;
    }
    
    public User(int id){
        this.userId = id;
    }

    public User(String email, String firstName, String lastName, String userName, String password, int typeId, String type,String phoneNO) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.typeId = typeId;
        this.type = type;
        this.phoneNO = phoneNO;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
   
    

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getTypeId() {
        return typeId;
    }

    public void setTypeId(int typeId) {
        this.typeId = typeId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    

    public String getPhoneNO() {
        return phoneNO;
    }

    public void setPhoneNO(String phoneNO) {
        this.phoneNO = phoneNO;
    }
   
    
}