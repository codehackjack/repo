package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.User;

public class RegisterDao {
    private String url;
    private String userDB;
    private String passDB;
  
    
    public RegisterDao(){
    }
    
    public RegisterDao(String url, String userDB, String passDB){
        this.url = url;
        this.userDB = userDB;
        this.passDB = passDB;
    }
    
       protected Connection getConnection(){
       Connection conn = null;
       try{
           Class.forName("com.mysql.jdbc.Driver");
           if(conn==null || conn.isClosed()){
                conn = DriverManager.getConnection(url, userDB, passDB);
           }
       } catch(SQLException sqlEx){
           sqlEx.printStackTrace();
       } catch(ClassNotFoundException ex){
           ex.printStackTrace();
       }
       return conn;
   }
    
    public int addUser(User userObj){
        int res = 0;
        String sql = "INSERT INTO marketingagent (firstName, lastName, phoneNo, email, "
                + "userName, password, typeid, type) VALUES (?,?,?,?,?,?,?,?)";
        try{
            Connection conn = getConnection();
            if(conn!=null){
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, userObj.getFirstName());
                stmt.setString(2, userObj.getLastName());
                stmt.setString(3, userObj.getPhoneNO());
                stmt.setString(4, userObj.getEmail());
                stmt.setString(5, userObj.getUserName());
                stmt.setString(6, userObj.getPassword());
                stmt.setInt(7, userObj.getTypeId());
                stmt.setString(8, userObj.getType());

                res = stmt.executeUpdate();
                conn.close();
            }
            
        } catch (SQLException sqlEx){
            sqlEx.printStackTrace();
        }
        return res;
    }
    
   public ArrayList<User> viewUsers(){
       ArrayList<User> userList = new ArrayList();
       String sql = "SELECT * FROM marketingagent";

        String email;
        String firstName;
        String lastName;
        String userName;
        String phoneNo;
        int typeId;
        String type;
        int id = 0;
       
       try{
        Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        ResultSet resultSet = stmt.executeQuery(sql);

        while(resultSet.next()){
            firstName = resultSet.getString("firstName");
            lastName = resultSet.getString("lastName");
            email = resultSet.getString("email");
            phoneNo = resultSet.getString("phoneNo");
            userName = resultSet.getString("userName");
            type = resultSet.getString("type");
            typeId = resultSet.getInt("typeId");
            id = resultSet.getInt("id");
            
            User userObj = new User(id, email, firstName, lastName, userName, typeId, type, phoneNo);

            userList.add(userObj);
        }
       resultSet.close();
       stmt.close();
        if(conn!=null && !conn.isClosed()){
         conn.close();
        }
       } catch(SQLException sqlEx){
           sqlEx.printStackTrace();
       }
       return userList;
   }
   
   public User showUser(int id) throws SQLException{
       User userObj = null;
       String sql = "SELECT * FROM marketingagent ";
       sql += "WHERE id = ?";
       
       Connection con = getConnection();
       PreparedStatement statement = con.prepareStatement(sql);
       statement.setInt(1, id);
       ResultSet result = statement.executeQuery();
       
       while(result.next()){
           userObj = new User();
           userObj.setUserId(result.getInt("id"));
           userObj.setFirstName(result.getString("firstName"));
           userObj.setLastName(result.getString("lastName"));
           userObj.setEmail(result.getString("email"));
           userObj.setPassword(result.getString("password"));
           userObj.setPhoneNO(result.getString("PhoneNO"));

       }
       return userObj;
   }

   public boolean updateUser(User userObj) throws SQLException{
       boolean res;
       String sql = "UPDATE marketingagent SET firstName = ?, lastName = ? , email = ?, password = ?, phoneNo=?";
       sql += "WHERE id = ?";
       
       Connection con = getConnection();
       PreparedStatement statement = con.prepareStatement(sql);
       
       statement.setString(1, userObj.getFirstName());
       statement.setString(2, userObj.getLastName());
       statement.setString(3, userObj.getEmail());
       statement.setString(4, userObj.getPassword());
       statement.setString(5, userObj.getPhoneNO());
       statement.setInt(6, userObj.getUserId());
       res = statement.executeUpdate() > 0;
       
       return res;
   
   }
   public boolean deleteUser(User userObj) throws SQLException{
       boolean res;
       String sql = "delete from marketingagent ";
       sql += "WHERE id = ?";
       
       Connection con = getConnection();
       PreparedStatement statement = con.prepareStatement(sql);
      
       statement.setInt(1, userObj.getUserId());
       
       res = statement.executeUpdate() > 0;
       
       return res;
   }
}
