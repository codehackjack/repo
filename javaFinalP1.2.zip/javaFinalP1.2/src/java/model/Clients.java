
package model;


public class Clients {
int  agentId ;
String firstName ;
String lastName ;
String streetNumber ;
String streetName ;
String city ;
String province ;
String postalCode ;
String telOffice ;
String telCell ;
String email ;
String company ;
String companyType ;
    
}
