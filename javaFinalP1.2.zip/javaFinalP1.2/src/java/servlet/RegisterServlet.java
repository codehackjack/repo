package servlet;

import dao.LocationDao;
import dao.RegisterDao;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Location;
import model.User;
import services.LocationService;
import services.RegisterService;

public class RegisterServlet extends HttpServlet {
    RegisterService registerService;
    RegisterDao registerDao;

    String jdbcUserName;
    String jdbcPassword;
    String jdbcURL;
    
    ///Location
    LocationService locationService;
    LocationDao locationDao;
    
    @Override
    public void init() throws ServletException {
        jdbcURL = getServletContext().getInitParameter("jdbcURL");
        jdbcUserName = getServletContext().getInitParameter("jdbcUserName");
        jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
        
        registerDao = new RegisterDao(jdbcURL, jdbcUserName, jdbcPassword);
        registerService = new RegisterService();
        
        locationDao = new LocationDao(jdbcURL, jdbcUserName, jdbcPassword);
        locationService = new LocationService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=request.getServletPath();
        
        //String action = request.getParameter("submit");
        switch(action){
            // Markting AGENT
            case "/new":
                showNewUserForm(request, response);
                break;
                
            case "/insert":
                addUser(request, response);
                break;
            
            case "/edit":
                showEditForm(request, response);
                break;
            
            case "/update":
                updateUser(request, response);
                break;
            
            case "/delete":
                deleteUser(request, response);
                break;
                
            //location
            case "/newLocation":
                showNewLocationForm(request, response);
                break;
                
            case "/insertLocation":
                addLocation(request, response);
                break;
            
            case "/editLocation":
                showEditFormLocation(request, response);
                break;
            
            case "/updateLocation":
                updateLocation(request, response);
                break;
            
            case "/deleteLocation":
                deleteLocation(request, response);
                break;
            case "/listLocation":
                viewLocation(request, response);
                break;
            case "/list":
                viewUsers(request, response);
                break;
            case "/login":
                {
                    try {
                        login(request, response);
                    } catch (SQLException ex) {
                        Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                break;
            case "/logout":
                {
                    try {
                        login(request, response);
                    } catch (SQLException ex) {
                        Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                break;
            default:
                {
                    try {
                        login(request, response);
                    } catch (SQLException ex) {
                        Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;
           
        }
    }
    private void login(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException, SQLException{
        String username,password;
        username = request.getParameter("username");
        password = request.getParameter("password");
        int log = registerDao.login(username, password);
        RequestDispatcher dispatcher;
        if(log==1){
            dispatcher = request.getRequestDispatcher("viewUserList.jsp");
        }else if(log==2){
            dispatcher = request.getRequestDispatcher("viewLocationList.jsp");
        }else{
            dispatcher = request.getRequestDispatcher("login.jsp");
        }
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    
    protected void addUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String phoneNo = request.getParameter("phoneNo");
        String email = request.getParameter("email");
       
        
        int res = registerService.addUser(firstName, lastName, phoneNo, email, registerDao);
        
        if(res>0){
           RequestDispatcher dispatcher = request.getRequestDispatcher("list");
           dispatcher.forward(request, response);
        } else {
           response.sendRedirect("error.jsp");
        }
    }
    
    protected void viewUsers(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
        ArrayList<User> userList = new ArrayList();
        userList = registerService.viewUsers(registerDao);
        
        request.setAttribute("userList", userList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewUserList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewUserForm(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{
        RequestDispatcher dispatcher = request.getRequestDispatcher("registerUser.jsp");
        dispatcher.forward(request, response);
    }

    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException{
        int id = Integer.parseInt(request.getParameter("id"));
        try{
            User user = registerService.showUser(id,registerDao);
            request.setAttribute("user",user);
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("editUserForm.jsp");
            dispatcher.forward(request,response);
            
        } catch(SQLException sqlEx){
            sqlEx.printStackTrace();
        }
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException{
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String phoneNo = request.getParameter("phoneNo");
        String email = request.getParameter("email");
      
        int id = Integer.parseInt(request.getParameter("id"));
        
        User userObj = new User(id,firstName, lastName, phoneNo, email);
        try{
            registerService.updateUser(userObj,registerDao);
        } catch(SQLException ex){
            ex.printStackTrace();
        }
        
        response.sendRedirect("list");
    }
    private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException{

        int id = Integer.parseInt(request.getParameter("id"));
        
        User userObj = new User(id);
        try{
            registerService.deleteUser(userObj,registerDao);
        } catch(SQLException ex){
            ex.printStackTrace();
        }
        
        response.sendRedirect("list?id="+id);
    }
  
    // Location
    
    protected void addLocation(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String locationName = request.getParameter("locationName");
        int distributionCapacity = Integer.parseInt(request.getParameter("distributionCapacity"));       
        int res = locationService.addLocation(locationName, distributionCapacity, locationDao);
        
        if(res>0){
           RequestDispatcher dispatcher = request.getRequestDispatcher("listLocation");
           dispatcher.forward(request, response);
        } else {
           response.sendRedirect("error.jsp");
        }
    }
    
    protected void viewLocation(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
        ArrayList<Location> locationList = new ArrayList();
        locationList = locationService.viewLocation(locationDao);
        
        request.setAttribute("locationList", locationList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewLocationList.jsp");
        dispatcher.forward(request, response);
        
        /*
        ArrayList<User> userList = new ArrayList();
        userList = registerService.viewUsers(registerDao);
        
        request.setAttribute("userList", userList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewUserList.jsp");
        dispatcher.forward(request, response);
        */

    }

    private void showNewLocationForm(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException{
        RequestDispatcher dispatcher = request.getRequestDispatcher("registerLocation.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditFormLocation(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException{
        int id = Integer.parseInt(request.getParameter("id"));
        try{
            Location location = locationService.showLocation(id,locationDao);
            request.setAttribute("location",location);
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("editLocationForm.jsp");
            dispatcher.forward(request,response);
            
        } catch(SQLException sqlEx){
            sqlEx.printStackTrace();
        }
    }

    private void updateLocation(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException{
        String locationName = request.getParameter("locationName");
        int distributionCapacity = Integer.parseInt(request.getParameter("distributionCapacity"));
        int id = Integer.parseInt(request.getParameter("id"));
        
        Location locObj = new Location(id,locationName, distributionCapacity);
        try{
            locationService.updateLocation(locObj,locationDao);
        } catch(SQLException ex){
            ex.printStackTrace();
        }
        
        response.sendRedirect("listLocation");
    }
    private void deleteLocation(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException{

        int id = Integer.parseInt(request.getParameter("id"));
        
        Location locObj = new Location(id);
        try{
            locationService.deleteLocation(locObj,locationDao);
        } catch(SQLException ex){
            ex.printStackTrace();
        }
        
        response.sendRedirect("listLocation?id="+id);
    }
}
