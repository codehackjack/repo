package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Location;

public class LocationDao {

    private String url;
    private String userDB;
    private String passDB;

    public LocationDao() {
    }

    public LocationDao(String url, String userDB, String passDB) {
        this.url = url;
        this.userDB = userDB;
        this.passDB = passDB;
    }

    protected Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(url, userDB, passDB);
            }
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    public int addLocation(Location locObj) {
        int res = 0;
        String sql = "INSERT INTO location (LocationName, DistributionCapacity) VALUES (?,?)";
        try {
            Connection conn = getConnection();
            if (conn != null) {
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, locObj.getLocationName());
                stmt.setInt(2, locObj.getDistributionCapacity());


                res = stmt.executeUpdate();
                conn.close();
            }

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
        return res;
    }

    public ArrayList<Location> viewLocations() {
        ArrayList<Location> locList = new ArrayList();
        String sql = "SELECT * FROM location ";
        String locationName = "";
        int distributionCapacity;
        int id = 0;
        try {
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery(sql);
            while (resultSet.next()) {
                locationName = resultSet.getString("locationName");
                distributionCapacity = resultSet.getInt("distributionCapacity");
                id = resultSet.getInt("id");
                Location locObj = new Location();
                locObj.setId(id);
                locObj.setLocationName(locationName);
                locObj.setDistributionCapacity(distributionCapacity);
                locList.add(locObj);
            }
            resultSet.close();
            stmt.close();
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
        return locList;
    }

    public Location showLoc(int id) throws SQLException {
        Location locObj = null;
        String sql = "SELECT * FROM location ";
        sql += "WHERE id = ?";

        Connection con = getConnection();
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet result = statement.executeQuery();

        while (result.next()) {
            locObj = new Location();
            locObj.setId(result.getInt("id"));
            locObj.setLocationName(result.getString("locationName"));
            locObj.setDistributionCapacity(result.getInt("distributionCapacity"));

        }
        return locObj;
    }

    public boolean updateLocation(Location locObj) throws SQLException {
        boolean res;
        String sql = "UPDATE location SET locationName = ?, distributionCapacity = ?";
        sql += "WHERE id = ?";
        Connection con = getConnection();
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setString(1, locObj.getLocationName());
        statement.setInt(2, locObj.getDistributionCapacity());
        statement.setInt(3, locObj.getId());
        res = statement.executeUpdate() > 0;

        return res;

    }

    public boolean deleteLocation(Location locObj) throws SQLException {
        boolean res;
        String sql = "delete from location ";
        sql += "WHERE id = ?";

        Connection con = getConnection();
        PreparedStatement statement = con.prepareStatement(sql);

        statement.setInt(1, locObj.getId());

        res = statement.executeUpdate() > 0;

        return res;
    }
}
